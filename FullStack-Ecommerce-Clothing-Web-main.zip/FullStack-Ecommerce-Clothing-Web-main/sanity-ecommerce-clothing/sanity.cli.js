import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'dow10h3v',
    dataset: 'production'
  }
})
